# README #

Jenkinsfile is updated with ec2-user as user name to connect with Ansible, K8s master nodes while copying the config files and running the tasks remotely. 
ing

#Testing Web Hooks ###

### What is this repository for ####

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ##

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact
